function [in1, in2, duty, st_out, pos_mm, det] = door_ctrl(v_ir, cnt_raw)
%#codegen
% =========================================================================
%  자동문 제어 연산 (Simulink "MATLAB Function" 블록에 붙여 넣는 코드)
%  Updated: 2026-11-26 06:20 (검토 반영: 열림 중 멈춤 보호, 출력 double, 변수 이름)
%  최종 사양: 낚시 합사 0.4mm + 지름 12mm 풀리(유효 12.4mm), 문 80mm x 2,
%             최대 출입구 90mm(문 한 짝 45mm 이동), 내부 길이 282mm
%
%  입력 : v_ir    - GP2Y0A21 전압 [V]         <- HIL Read Analog (AI 0)
%         cnt_raw - 엔코더 카운트(4체배)      <- HIL Read Encoder
%  출력 : in1,in2 - L298N 방향 (0 또는 1)      -> HIL Write Digital (DIO 0,1)
%         duty    - L298N ENA 듀티 0~1        -> HIL Write PWM
%         st_out  - 현재 상태 번호 (Scope/Display 확인용)
%         pos_mm  - 문 위치 [mm] (0 = 닫힘, 45 = 완전 열림)
%         det     - 센서 감지 여부
%  상태 : 0 기준값 측정 / 1 원점 찾기 / 2 닫힘 / 3 여는 중 / 4 열림 / 5 닫는 중
% =========================================================================

%% ---- 파라미터 (실측 후 여기만 고치면 됨) ----
Ts           = 0.001;  % 샘플 시간 [s] - 모델의 고정 스텝과 같게
ENC_SIGN     = 1;      % 문을 열 때 카운트가 줄어들면 -1 로
CNT_PER_MM   = 66.74;  % 2600 / (pi * 12.4)
CNT_OPEN     = 3003;   % 완전 열림 45 mm
SLOW_OPEN    = 2403;   % 열 때 감속 시작 36 mm
SLOW_CLOSE   = 601;    % 닫을 때 감속 시작 9 mm
NEAR_CLOSED  = 133;    % 2 mm 이내에서 멈추면 '닫힘 완료'로 처리
D_OPEN_FAST  = 0.70;  D_OPEN_SLOW  = 0.30;
D_CLOSE_FAST = 0.60;  D_CLOSE_SLOW = 0.25;  D_HOME = 0.30;
CAL_T     = 0.5;   % 시작 시 센서 기준값 측정 시간 [s] (빔 앞을 비워 둘 것)
HOLD_T    = 3.0;   % 마지막 감지 후 닫힐 때까지 [s]
DET_DV    = 0.30;  % 기준값보다 이만큼 높으면 감지 [V]
DET_T     = 0.12;  % 감지가 이 시간 계속되어야 인정 [s]
GRACE_T   = 0.20;  % 출발 직후 멈춤 판정을 하지 않는 시간 [s]
STALL_T   = 0.10;  % 멈춤이 이 시간 계속되면 끼임 [s]
STALL_SPD = 5;     % 10 ms당 카운트 변화가 이보다 작으면 '멈춤' (실측 후 조정)
OPEN_STALL_T = 0.30; % 여는 중 멈춤이 이 시간 계속되면 모터를 끄고 '열림'으로 처리 [s]

%% ---- 기억 변수 (매 샘플마다 값이 유지됨) ----
persistent st t t_st t_hold t_det t_stall cnt0 base acc n vf last k spd
if isempty(st)
    st = 0; t = 0; t_st = 0; t_hold = 0; t_det = -1; t_stall = -1;
    cnt0 = 0; base = 0; acc = 0; n = 0; vf = v_ir; last = 0; k = 0; spd = 0;
end

t   = t + Ts;
cnt = ENC_SIGN * double(cnt_raw);
pos = cnt - cnt0;                       % 0 = 닫힘

% 속도: 10 ms마다 카운트 변화량 (열면 +, 닫으면 -)
k = k + 1;
if k >= 10
    spd = cnt - last;  last = cnt;  k = 0;
end

% 센서: 저역 필터 + '연속 감지' 시간 확인
vf  = vf + 0.1 * (v_ir - vf);
raw = (st >= 2) && (vf > base + DET_DV);
if raw
    if t_det < 0, t_det = t; end
else
    t_det = -1;
end
det = double(raw && (t - t_det >= DET_T));

%% ---- 상태 기계 ----
mdir = 0;  d = 0;
switch st
    case 0  % 기준값 측정: 모터 정지, 빈 상태 전압 평균
        acc = acc + v_ir;  n = n + 1;
        if t - t_st >= CAL_T
            base = acc / n;  last = cnt;  st = 1;  t_st = t;  t_stall = -1;
        end

    case 1  % 원점 찾기: 천천히 닫다가 멈추면 그 자리를 0으로
        mdir = -1;  d = D_HOME;
        if (t - t_st > 0.5) && (spd > -2)
            if t_stall < 0, t_stall = t; end
            if t - t_stall >= 0.2
                cnt0 = cnt;  mdir = 0;  st = 2;  t_st = t;  t_stall = -1;
            end
        else
            t_stall = -1;
        end

    case 2  % 닫힘
        if det > 0
            st = 3;  t_st = t;  t_stall = -1;
        end

    case 3  % 여는 중 (끝 20%에서 감속)
        mdir = 1;
        if pos < SLOW_OPEN, d = D_OPEN_FAST; else, d = D_OPEN_SLOW; end
        if pos >= CNT_OPEN
            mdir = 0;  st = 4;  t_st = t;  t_hold = t;
        elseif (t - t_st > GRACE_T) && (spd < STALL_SPD)
            % 보호: 여는 중 막히거나 끝에 닿아 멈추면 계속 밀지 않고 정지
            if t_stall < 0, t_stall = t; end
            if t - t_stall >= OPEN_STALL_T
                mdir = 0;  st = 4;  t_st = t;  t_hold = t;  t_stall = -1;
            end
        else
            t_stall = -1;
        end

    case 4  % 열림 유지: 감지되는 동안 타이머를 계속 다시 시작
        if det > 0, t_hold = t; end
        if t - t_hold >= HOLD_T
            st = 5;  t_st = t;  t_stall = -1;
        end

    otherwise  % 5: 닫는 중
        mdir = -1;
        if pos > SLOW_CLOSE, d = D_CLOSE_FAST; else, d = D_CLOSE_SLOW; end
        if det > 0
            st = 3;  t_st = t;  t_stall = -1;       % 사람 감지 -> 다시 열기
        elseif pos <= 0
            mdir = 0;  st = 2;  t_st = t;            % 닫힘 완료
        elseif (t - t_st > GRACE_T) && (spd > -STALL_SPD)
            if t_stall < 0, t_stall = t; end
            if t - t_stall >= STALL_T
                if pos > NEAR_CLOSED
                    st = 3;                         % 도중에 막힘 -> 다시 열기
                else
                    mdir = 0;  st = 2;               % 끝에서 멈춤 -> 닫힘 완료
                end
                t_st = t;  t_stall = -1;
            end
        else
            t_stall = -1;
        end
end

%% ---- 출력 ----
in1 = double(mdir > 0);               % 열기: IN1=1, IN2=0
in2 = double(mdir < 0);               % 닫기: IN1=0, IN2=1
if mdir == 0, duty = 0; else, duty = d; end
st_out = st;
pos_mm = pos / CNT_PER_MM;
end
